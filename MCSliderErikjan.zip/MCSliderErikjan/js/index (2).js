const pricesPreGB = {
  budget: 1.75, // EURO
  premium: 3.0, // EURO
};

var ultimate = {
  id: 269,
  ram_configoption: 98,
  ram: {
    // PRICE AS PER PLAN
    // You can as many plans as you want like:
    /* 20: { id: 222, price: 200} */
    // 6GB: 15.0 EURO
    6: { id: 556, price: 15.0 },
    // 8GB: 20.0 EURO
    8: { id: 558, price: 20.0 },
    // 10 GB: 25.0 EURO
    10: { id: 559, price: 25.0 },
    // 12 GB: 30.0 EURO
    12: { id: 560, price: 30.0 },
    // 16 GB: 40.0 EURO
    16: { id: 561, price: 40.0 },
    // 25 GB: 62.5 EURO
    25: { id: 567, price: 62.5 },
  },
  storage_configoption: 99,
    // PRICE AS PER PLAN
    // You can as many plans as you want like:
    /* 20: { id: 222, price: 200} */
    // 6GB: 15.0 EURO
    6: { id: 556, price: 15.0 },
    // 8GB: 20.0 EURO
    8: { id: 558, price: 20.0 },
    // 10 GB: 25.0 EURO
    10: { id: 559, price: 25.0 },
    // 12 GB: 30.0 EURO
    12: { id: 560, price: 30.0 },
    // 16 GB: 40.0 EURO
    16: { id: 561, price: 40.0 },
    // 25 GB: 62.5 EURO
    25: { id: 567, price: 62.5 },
};

var PIDs = {
  budget: {
    3: 196,
    4: 198,
    5: 199,
    6: 197,
    8: 200,
    10: 201,
    12: 203,
    16: 204,
    20: 206,
    24: 205,
  },
  premium: {
    3: 209,
    4: 210,
    5: 211,
    6: 212,
    7: 213,
    8: 214,
    10: 216,
    12: 217,
    16: 218,
    24: 219,
  },
};

function ucfirst(s) {
  return s.charAt(0).toUpperCase() + s.slice(1);
}
function get_plans(type) {
  return Object.keys(PIDs[type])
    .map((k) => {
      var price = parseInt(k) * pricesPreGB[type];
      var minperiod = "monthly";
      return {
        name: k + "GB " + ucfirst(type) + " Minecraft",
        price: price,
        ram: k + "GB",
        cycle: minperiod,
        ram_gb: parseInt(k),
        orderlink:
          "https://client.navynode.com/order.php?pid=" + PIDs[type][k],
      };
    })
    .reduce(function (result, item, index, array) {
      result[item.ram_gb] = item;
      return result;
    }, {});
}
var index = 1;
var type = $("input[name=hosting_type]").val();
var info = get_plans(type);
function setup_slider(main) {
  var self = main,
    sliderUI = self.find(".slider-line"),
    sliderInp = self.find(".slider-inp"),
    sliderUniqueId = "sliderUI" + index,
    inputUniqueId = "inputUI" + index,
    start = parseInt(sliderInp.attr("data-start"));
  sliderUI.attr("id", sliderUniqueId);
  sliderInp.attr("id", inputUniqueId);
  index++;
  var count_step = Object.keys(info).length;
  var keypressSlider = document.getElementById(sliderUniqueId),
    input = document.getElementById(inputUniqueId);
  var slider = noUiSlider.create(keypressSlider, {
    start: start ? start : 1,
    step: 1,
    connect: "lower",
    tooltips: true,
    format: {
      to: function (ind) {
        var gb = info[Object.keys(info)[parseInt(ind) - 1]].ram_gb;
        return parseInt(gb) + "GB " + ucfirst(type) + " Minecraft";
      },
      from: function (value) {
        return value;
      },
    },
    range: { min: 1, max: Object.keys(info).length },
    pips: {
      mode: "values",
      values: Object.keys(info).map((val, ind) => ind + 1),
      density: 5,
      stepped: false,
      format: {
        to: function (a) {
          return info[Object.keys(info)[parseInt(a) - 1]].ram;
        },
      },
    },
  });
  function getValue2(values, handle, unencoded, tap) {
    var circle = $(this.target).closest(".sidebar").find(".circle");
    circle.attr("data-percent", (parseInt(unencoded) / count_step) * 100);
  }
  keypressSlider.noUiSlider.on("change", getValue2);
  keypressSlider.noUiSlider.on("update", function (values, handle) {
    refreshInfo(values[handle]);
    input.value = values[handle];
    change_global_cloud_pkgs_href(values[handle]);
  });
  input.addEventListener("change", function () {
    keypressSlider.noUiSlider.set([null, this.value]);
  });
  input.addEventListener("keydown", function (e) {
    var value = Number(keypressSlider.noUiSlider.get()),
      sliderStep = keypressSlider.noUiSlider.steps();
    sliderStep = sliderStep[0];
    switch (e.which) {
      case 13:
        keypressSlider.noUiSlider.set(this.value);
        break;
      case 38:
        keypressSlider.noUiSlider.set(value + sliderStep[1]);
        break;
      case 40:
        keypressSlider.noUiSlider.set(value - sliderStep[0]);
        break;
    }
  });
  function refreshInfo(key) {
    var gb = parseInt(key.split("GB")[0]);

    $("#orderlink-val").html(info[gb].orderlink);
    $("#price-val").html(info[gb].price.toFixed(2));
    $(".del-price").html((info[gb].price + pricesPreGB[type]).toFixed(2));
    $("#cycle-val").html(
      "/" + info[gb].cycle.substr(0, info[gb].cycle.length - 2)
    );
    $("#plan-name").html(gb + "GB " + ucfirst(type) + " Minecraft");
  }
  function change_global_cloud_pkgs_href(key) {
    var gb = parseInt(key.split("GB")[0]);
    $("#orderlink").attr("href", info[gb].orderlink);
  }
  return slider;
}
var slider = setup_slider($("#plan-slider"));
var ver = "1.13-to-1.16";
var jar = "spigot";
var recommendation = 3;
function calc_recommendation() {
  switch (jar) {
    case "spigot":
      return {
        "1.17-to-1.21": 6,
        "1.13-to-1.16": 4,
        "1.9-to-1.13": 3,
        "1.8.8-below": 2,
        "not-sure": 4,
      }[ver];
    case "vanilla":
      return {
        "1.17-to-1.21": 5,
        "1.13-to-1.16": 3,
        "1.9-to-1.13": 2,
        "1.8.8-below": 1,
        "not-sure": 4,
      }[ver];
    case "bedrock":
      return {
        "1.17-to-1.21": 4,
        "1.13-to-1.16": 3,
        "1.9-to-1.13": 2,
        "1.8.8-below": 2,
        "not-sure": 2,
      }[ver];
    case "forge":
      return {
        "1.17-to-1.21": 8,
        "1.13-to-1.16": 6,
        "1.9-to-1.13": 5,
        "1.8.8-below": 4,
        "not-sure": 6,
      }[ver];
  }
}
function update_recommendation(initial) {
  recommendation = calc_recommendation();
  $("#chosen-version").text(
    {
     "1.17-to-1.21": "1.17 to 1.21",
      "1.13-to-1.16": "1.13.2 to 1.16.5",
      "1.9-to-1.13": "1.9 to 1.13.2",
      "1.8.8-below": "1.8.8 or below",
      "not-sure": "I'm not sure",
    }[ver]
  );
  $("#chosen-jar").text(
    {
      spigot: "Spigot / Paper",
      vanilla: "Vanilla Minecraft",
      bedrock: "Bedrock",
      forge: "Forge Modpack",
      "not-sure": "I'm not sure",
    }[jar]
  );
  $("#chosen-ram").text(recommendation + "GB");
  if (initial) recommendation = 5;
  var i = 1;
  for (var key in info) {
    if (parseInt(key) === parseInt(recommendation)) {
      slider.set(i);
    }
    i++;
  }
}
$("#choose-version").change(function () {
  ver = $(this).find("option:selected").val();
  update_recommendation();
});
$("#choose-jar").change(function () {
  jar = $(this).find("option:selected").val();
  update_recommendation();
});
update_recommendation(true);

$(".mobile-specopts").click(function () {
  $(this).next().slideToggle();
});

if (window.innerWidth <= 576) {
  $(".specsinfo").hide();
}

$(".plan-btn").click(function () {
  Array.from($(".plan-btn")).forEach((el) => {
    $(el).removeClass("btn-gray", "active-btn");
  });
  const current = $(this);
  current.addClass("active-btn");
  if (current.data("plan") === "budget") $(".standalone-premium-upsell").show();
  else $(".standalone-premium-upsell").hide();
  if (current.data("plan") !== "ultimate") {
    $(".budget-premium").slideDown();
    $(".ultimate").slideUp();
    info = get_plans(current.data("plan"));
    update_recommendation(true);
  } else {
    $(".budget-premium").slideUp();
    $(".ultimate").slideDown();
    Object.assign(mainSlides, init());
  }
});

const mainSlides = {};

const init = function () {
  var index = 0;
  function setup_ram_slider(main) {
    var self = main,
      sliderUI = self.find(".slider-line"),
      sliderInp = self.find(".slider-inp"),
      sliderUniqueId = "sliderUI-ultimate" + index,
      inputUniqueId = "inputUI-ultimate" + index;
    sliderUI.attr("id", sliderUniqueId);
    sliderInp.attr("id", inputUniqueId);
    index++;
    var count_step = Object.keys(ultimate.ram).length;
    var keypressSlider = document.getElementById(sliderUniqueId),
      input = document.getElementById(inputUniqueId);
    var slider = noUiSlider.create(keypressSlider, {
      start: 0,
      step: 1,
      connect: "lower",
      tooltips: true,
      format: {
        to: function (ind) {
          return Object.keys(ultimate.ram)[parseInt(ind)] + "GB";
        },
        from: function (value) {
          return value;
        },
      },
      range: { min: 0, max: Object.keys(ultimate.ram).length - 1 },
      pips: {
        mode: "values",
        values: Object.keys(ultimate.ram).map((val, ind) => ind),
        density: 5,
        stepped: false,
        format: {
          to: function (a) {
            return Object.keys(ultimate.ram)[parseInt(a)] + "GB";
          },
        },
      },
    });
    function getValue2(values, handle, unencoded, tap) {
      var circle = $(this.target).closest(".sidebar").find(".circle");
      circle.attr("data-percent", (parseInt(unencoded) / count_step) * 100);
    }
    keypressSlider.noUiSlider.on("change", getValue2);
    keypressSlider.noUiSlider.on("update", function (values, handle) {
      input.value = values[handle];
      refresh_info();
    });
    input.addEventListener("change", function () {
      keypressSlider.noUiSlider.set([null, this.value]);
    });
    input.addEventListener("keydown", function (e) {
      var value = Number(keypressSlider.noUiSlider.get()),
        sliderStep = keypressSlider.noUiSlider.steps();
      sliderStep = sliderStep[0];
      switch (e.which) {
        case 13:
          keypressSlider.noUiSlider.set(this.value);
          break;
        case 38:
          keypressSlider.noUiSlider.set(value + sliderStep[1]);
          break;
        case 40:
          keypressSlider.noUiSlider.set(value - sliderStep[0]);
          break;
      }
    });
    return slider;
  }
  var ramslider = mainSlides.ramslider || setup_ram_slider($("#ram-slider"));
  function refresh_info() {
    if (!ramslider) return;
    var ram_gb = parseInt(ramslider.get().split("GB")[0]);
    var ram_details = ultimate.ram[ram_gb];
    $(".ultimate-plan").text("ultimate " + ram_gb + "GB");
    $(".ultimate-card .price-val").text(ram_details.price.toFixed(2));
    $(".ultimate-card .del-value").text((ram_details.price + 5).toFixed(2));
    $("#cycle-val").text("/month");
    $("#orderlink").attr(
      "href",
      "https://client.navynode.com/cart.php?" +
        new URLSearchParams({
          a: "add",
          pid: ultimate.id,
          ["configoption[" + ultimate.ram_configoption + "]"]: ram_details.id,
        }).toString()
    );
  }
  refresh_info();
  return { ramslider };
};
